import torch
import torch.nn as nn

class BinaryModel(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, activation: str = 'relu'):
        super(BinaryModel, self).__init__()
        # Hidden layer with activation
        self.hidden = nn.Linear(input_size, hidden_size)
        self.hidden_activation = self._get_activation(activation)
        
        # Output layer with activation (sigmoid)
        self.output = nn.Linear(hidden_size, 1)
        self.sigmoid = nn.Sigmoid()
        
        self.activation_name = activation.lower()
    
    def _get_activation(self, activation):
        if activation.lower() == 'relu':
            return nn.ReLU()
        elif activation.lower() == 'sigmoid':
            return nn.Sigmoid()
        elif activation.lower() == 'tanh':
            return nn.Tanh()
        else:
            raise ValueError(f"Unsupported activation function: {activation}")
    
    def forward(self, x, return_hidden=True):
        # Hidden layer with activation
        hidden_output = self.hidden(x)
        hidden_output = self.hidden_activation(hidden_output)
        
        # Output layer with activation (sigmoid)
        output = self.output(hidden_output)
        output = self.sigmoid(output)
        
        # Ensure output has shape (batch_size, 1)
        if len(output.shape) == 1:
            output = output.unsqueeze(1)
        
        if return_hidden:
            return output, hidden_output
        return output 