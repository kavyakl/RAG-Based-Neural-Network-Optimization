"""
Neural network model implementations.
""" 